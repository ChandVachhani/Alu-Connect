from django.apps import AppConfig


class AlumniConfig(AppConfig):
    name = 'alumni'
